# Watu-inspired Static Starter Site

This is a small static starter site inspired by electronics storefronts (hero, features, product grid, contact page). All text and images are placeholders and original — no content copied from other websites.

Contact details embedded in this branch:
- Email: wairimuwatucredit@gmail.com
- Phone: +254102326232
- TikTok: https://www.tiktok.com/@watu.creditke

How to use
1. Replace placeholder images (currently using picsum.photos) with real product photos by updating the image src attributes in index.html and contact.html.
2. Edit contact info in `contact.html` and the footer in `index.html` if needed.
3. Customize colors in `styles.css`.

Deploy
- To GitHub Pages: push to a repository and enable Pages from the repository settings (branch: main / gh-pages) or use the `gh-pages` action.
- Any static host works: Netlify, Vercel, Firebase Hosting, S3 + CloudFront.

Notes
- The branch `watu-starter-site` contains the starter files. Images are CC0 placeholders from picsum.photos as requested.
- If you want me to swap any placeholders for specific images from watu.com, provide the direct image URLs and I can hotlink them instead.
