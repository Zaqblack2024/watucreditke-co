// Small UI helpers
document.getElementById('year').textContent = new Date().getFullYear();

// Helper: Replace footer contact if provided as a query (optional)
(function(){
  // Example: index.html?contactName=Acme&contactEmail=hello@acme.com
  const params = new URLSearchParams(location.search);
  const name = params.get('contactName');
  const phone = params.get('contactPhone');
  const email = params.get('contactEmail');
  if (name || phone || email) {
    const el = document.getElementById('footer-contact');
    el.innerHTML = [
      name ? `Name: ${name}` : '',
      phone ? `Phone: <a href="tel:${phone}">${phone}</a>` : '',
      email ? `Email: <a href="mailto:${email}">${email}</a>` : ''
    ].filter(Boolean).join('<br/>');
  }
})();

// Utility: open WhatsApp with prefilled message (cross-device)
function openWhatsApp(number, message) {
  // number: in international format without plus e.g., 254712345678
  // message: plain text
  try {
    const encoded = encodeURIComponent(message || 'Hello');
    const url = `https://wa.me/${number}?text=${encoded}`;
    window.open(url, '_blank', 'noopener');
  } catch (e) {
    console.error('Could not open WhatsApp', e);
    alert('Unable to open WhatsApp. Please use the contact links on the page.');
  }
}

// Optionally expose to global for inline onclicks
window.openWhatsApp = openWhatsApp;
